<?php 

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Share Story</title>
<link href="css/main.css" rel="stylesheet" type="text/css" media="screen"> 
<link rel="stylesheet" href="css/foundation.css" />
<link href='https://fonts.googleapis.com/css?family=Lato:400,700,300,900' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,700,300' rel='stylesheet' type='text/css'>
</head>
<body>

<?php 
	include('includes/nav.html'); 
?>

<div class="marginTop">
	
</div>
	<div class="row thankYou">
		<h2>Thank you for sharing your story.</h2>
		<p>Your story will be looked over and you will receive an email when it has been approved.</p>
	</div>


<?php
	// include('includes/footer.html');
?>


<script src="js/main.js"></script>

</body>


</html>