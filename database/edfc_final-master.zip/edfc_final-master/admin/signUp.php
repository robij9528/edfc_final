
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Create Admin Account</title>
<link href="css/main.css" rel="stylesheet" type="text/css" media="screen"> 
 <link rel="stylesheet" href="css/foundation.css" />
 <link href='https://fonts.googleapis.com/css?family=Ubuntu:400,300,700' rel='stylesheet' type='text/css'>
</head>
<body>

<?php 
	include('includes/nav.html'); 
?>

<?php
	include('includes/footer.html');
?>


<script src="js/main.js"></script>

</body>


</html>
